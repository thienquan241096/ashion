<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('js/mixitup.min.js') }}"></script>
<script src="{{ asset('js/jquery.countdown.min.js') }}"></script>
<script src="{{ asset('js/jquery.slicknav.js') }}"></script>
<script src="{{ asset('js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('js/jquery.nicescroll.min.js') }}"></script>
<script src="{{ asset('js/main.js') }}"></script>

<script src="{{ asset('cssAdmin/vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('cssAdmin/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('cssAdmin/vendor/jquery-easing/jquery.easing.min.js') }}"></script>
<script src="{{ asset('cssAdmin/js/sb-admin-2.min.js') }}"></script>
<script src="{{ asset('cssAdmin/vendor/chart.js/Chart.min.js') }}"></script>
{{-- <script src="{{ asset('cssAdmin/js/demo/chart-area-demo.js') }}"></script>
<script src="{{ asset('cssAdmin/js/demo/chart-pie-demo.js') }}"></script> --}}